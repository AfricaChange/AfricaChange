# africa-change-dev
# une plateforme de change qui permettra de faciliter les echanges de devises en Afrique de l'Ouest
git checkout --theirs README.md
git add README.md                    
git rebase --continue
